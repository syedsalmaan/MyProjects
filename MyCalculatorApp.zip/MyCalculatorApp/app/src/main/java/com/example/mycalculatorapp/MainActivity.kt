
package com.example.mycalculatorapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    var newOp = true
    var oldNum = ""
    var opr = ""

    private var textAction: EditText? = null
    private var button7: Button? = null
    private var button8: Button? = null
    private var button9: Button? = null
    private var button4: Button? = null
    private var button5: Button? = null
    private var button6: Button? = null
    private var button1: Button? = null
    private var button2: Button? = null
    private var button3: Button? = null
    private var plusButton: Button? = null
    private var minusButton: Button? = null
    private var multiplyButton: Button? = null
    private var clearButton: Button? = null
    private var button0: Button? = null
    private var divideButton: Button? = null
    private var equaltoButton: Button? = null
    private var dotButton: Button? = null




   // var editText:EditText = findViewById(R.id.editText)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        textAction = findViewById(R.id.editText)
        button7 = findViewById(R.id.button_seven)
        button8 = findViewById(R.id.button_eight)
        button9 = findViewById(R.id.button_nine)
        button4 = findViewById(R.id.button_four)
        button5 = findViewById(R.id.button_five)
        button6 = findViewById(R.id.button_six)
        button1 = findViewById(R.id.button_one)
        button2 = findViewById(R.id.button_two)
        button3 = findViewById(R.id.button_three)
        plusButton = findViewById(R.id.button_plus)
        minusButton = findViewById(R.id.button_minus)
        multiplyButton = findViewById(R.id.button_multiple)
        clearButton = findViewById(R.id.button_clear)
        button0 = findViewById(R.id.button_zero)
        divideButton = findViewById(R.id.button_divide)
        equaltoButton = findViewById(R.id.button_equal)
        dotButton =  findViewById(R.id.button_dot)
    }

    fun numberEvent(view: View) {
        if(newOp){
            textAction!!.setText("")
            newOp = false
        }
        var TextAction: String = textAction!!.text.toString()
        var buttons: Button = view as Button
        when(buttons.id){
            button0!!.id -> {TextAction += "0"}
            button1!!.id -> {TextAction += "1"}
            button2!!.id -> {TextAction += "2"}
            button3!!.id -> {TextAction += "3"}
            button4!!.id -> {TextAction += "4"}
            button5!!.id -> {TextAction += "5"}
            button6!!.id -> {TextAction += "6"}
            button7!!.id -> {TextAction += "7"}
            button8!!.id -> {TextAction += "8"}
            button9!!.id -> {TextAction += "9"}
            dotButton!!.id -> {TextAction += "."}

        }
        textAction!!.setText(TextAction)


    }

    fun operatorEvent(view: View) {
        newOp = true
        oldNum = textAction!!.text.toString()
        var opButton :Button = view as Button
        when(opButton.id){
            plusButton!!.id -> {opr = "+"}
            minusButton!!.id -> {opr = "-"}
            multiplyButton!!.id -> {opr = "*"}
            divideButton!!.id -> {opr = "/"}
        }

    }

    fun equalEvent(view: View) {
        var newInteger = textAction!!.text.toString()
        var result = 0.0
        when(opr){
            "+" -> {result = oldNum.toDouble() + newInteger.toDouble()}
            "-" -> {result = oldNum.toDouble() - newInteger.toDouble()}
            "*" -> {result = oldNum.toDouble() * newInteger.toDouble()}
            "/" -> {result = oldNum.toDouble() / newInteger.toDouble()}
        }
        textAction!!.setText(result.toString())
    }

    fun clearEvent(view: View) {
        textAction!!.setText("0")
        newOp = true
    }

    fun percentEvent(view: View) {
        var numbers :Double = textAction!!.text.toString().toDouble()/100
        textAction!!.setText(numbers.toString())
        newOp = true
    }


}