package com.example.mycalculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView


class MainActivity : AppCompatActivity() {
    private var textAction: TextView? = null
    private var button7: Button? = null
    private var button8: Button? = null
    private var button9: Button? = null
    private var button4: Button? = null
    private var button5: Button? = null
    private var button6: Button? = null
    private var button1: Button? = null
    private var button2: Button? = null
    private var button3: Button? = null
    private var plusButton: Button? = null
    private var minusButton: Button? = null
    private var multiplyButton: Button? = null
    private var clearButton: Button? = null
    private var button0: Button? = null
    private var divideButton: Button? = null
    private var equaltoButton: Button? = null
    var newOperator = true
    var oldNum = ""
    var operator = "+"
    var numbers = ""


//    var minusOperator: Int =
//    var multiplyOperator: Int =
//    var divideOperator: Int =



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        textAction = findViewById(R.id.textView)
        button7 = findViewById(R.id.button)
        button8 = findViewById(R.id.button8)
        button9 = findViewById(R.id.button9)
        button4 = findViewById(R.id.button4)
        button5 = findViewById(R.id.button5)
        button6 = findViewById(R.id.button6)
        button1 = findViewById(R.id.button7)
        button2 = findViewById(R.id.button2)
        button3 = findViewById(R.id.button3)
        plusButton = findViewById(R.id.button13)
        minusButton = findViewById(R.id.button14)
        multiplyButton = findViewById(R.id.button15)
        clearButton = findViewById(R.id.button10)
        button0 = findViewById(R.id.button11)
        divideButton = findViewById(R.id.button12)
        equaltoButton = findViewById(R.id.button16)

         buttonCickEvent()
        equaltoButton!!.setOnClickListener {
            var newNum = textAction!!.text.toString()
            var result = 0.0
            if(operator == "+"){
                result = oldNum.toString().toDouble() + newNum.toString().toDouble()
            }
            else if(operator == "-"){
                result = oldNum.toString().toDouble() - newNum.toString().toDouble()
            }
            else if(operator == "*"){
                result = oldNum.toString().toDouble() * newNum.toString().toDouble()
            }
            else{
                result = oldNum.toString().toDouble() / newNum.toString().toDouble()

            }
            textAction!!.setText(result.toString())

            }


        plusButton!!.setOnClickListener {
            newOperator = true
            oldNum = textAction!!.text.toString()
            operator = "+"

        }
        minusButton!!.setOnClickListener {
            newOperator = true
            oldNum = textAction!!.text.toString()
            operator = "-"

            //textAction!!.text = number
        }
        multiplyButton!!.setOnClickListener {
            newOperator = true
            oldNum = textAction!!.text.toString()
            operator = "*"

           // textAction!!.text = number
        }
        clearButton!!.setOnClickListener {
            newOperator = true
            textAction!!.setText("0")
            numbers = ""
        }

        divideButton!!.setOnClickListener {
            newOperator = true
            oldNum = textAction!!.text.toString()
            operator = "/"


        }



    }

    fun buttonCickEvent(){

        if(newOperator){
            textAction!!.setText("")
            newOperator = false
            numbers = ""
        }

         numbers = textAction!!.text.toString()


        button7!!.setOnClickListener {
            numbers += "7"
            textAction!!.setText(numbers)
        }
        button8!!.setOnClickListener {
            numbers += "2"
            textAction!!.setText(numbers)
        }
        button9!!.setOnClickListener {
            numbers += "3"
            textAction!!.setText(numbers)
        }
        button4!!.setOnClickListener {
            numbers += "5"
            textAction!!.setText(numbers)
        }
        button5!!.setOnClickListener {
            numbers += "4"
            textAction!!.setText(numbers)

        }
        button6!!.setOnClickListener {
            numbers += "6"
            textAction!!.setText(numbers)
        }
        button1!!.setOnClickListener {
            numbers += "1"
            textAction!!.setText(numbers)
        }
        button2!!.setOnClickListener {
            numbers += "8"
            textAction!!.setText(numbers)
        }
        button3!!.setOnClickListener {
            numbers += "9"
            textAction!!.setText(numbers)
        }
        button0!!.setOnClickListener {
            numbers += "0"
            textAction!!.setText(numbers)
        }
       // textAction!!.setText(numbers)
    }




}


