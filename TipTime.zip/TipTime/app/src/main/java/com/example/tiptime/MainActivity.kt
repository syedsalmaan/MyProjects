 package com.example.tiptime

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.tiptime.databinding.ActivityMainBinding
import java.text.NumberFormat

class MainActivity : AppCompatActivity() {

    lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.calculateButton.setOnClickListener {
            calculateTip()
        }

    }
    fun calculateTip() {
        val stringInTextField = binding.costOfService.editText!!.text.toString()
        val cost = stringInTextField.toDoubleOrNull()
        val selectedId = binding.tipOptions.checkedRadioButtonId
        val tipPercentage = when(selectedId){
            R.id.option_fifteen_percent -> 0.15
            R.id.option_eighteen_percent -> 0.18
            else -> 0.20
        }
        if (cost == null) {
            binding.result.text = ""
            return
        }
        var tip = tipPercentage * cost
        var x = binding.roundUpSwitch.isChecked
        if (x) {
            tip = kotlin.math.ceil(tip)
        }
       /// val formattedTip = NumberFormat.getCurrencyInstance().format(tip)
        binding.result.text = getString(R.string.tip_amount, tip.toString())


    }
}