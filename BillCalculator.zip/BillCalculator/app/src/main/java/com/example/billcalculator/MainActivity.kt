package com.example.billcalculator

import android.annotation.SuppressLint
import android.app.Activity
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import com.example.billcalculator.databinding.ActivityMainBinding
import java.text.NumberFormat

class MainActivity : AppCompatActivity() {

    lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.calculateButton.setOnClickListener {
            calculation()
        }

    }

    @SuppressLint("StringFormatMatches")
    fun calculation(){
        val edittext1 = binding.edittext1.text
        var costOf1 = edittext1.toString().toDoubleOrNull()
        val edittext2 = binding.edittext2.text
        var costOf2 = edittext2.toString().toDoubleOrNull()
        var totalCost = costOf1!! * costOf2!!


        val selectingOption = binding.tip.checkedRadioButtonId
        val percentOfTip = when(selectingOption){
            R.id.rupees_1 -> 1
            R.id.rupees_5 -> 5
            R.id.rupees_10 -> 10
            else -> 20
        }

        var formattedTip = totalCost!! + percentOfTip
        binding.result.text = getString(R.string.final_result, formattedTip )

    }
}